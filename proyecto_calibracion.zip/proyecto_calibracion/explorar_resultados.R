# =============================================================================
# explorar_resultados.R · Abrir en R la base analítica y todos los resultados
#
# Ejecutar DESPUÉS de run_all.R, con el proyecto abierto en RStudio.
# Recomendado: ir línea por línea con Ctrl + Enter (Cmd + Enter en Mac).
# =============================================================================

library(readr)
library(dplyr)

# --- 1. Base analítica -------------------------------------------------------
# Una fila por partido x casa x momento: cuotas, probabilidades brutas, margen,
# probabilidades normalizadas por cada método (p_<metodo>_H/D/A), parámetros
# de Shin y potencia, resultado observado y si el partido entra a la muestra.
base <- read_csv("data/processed/base_analitica.csv", show_col_types = FALSE)

glimpse(base)   # lista de columnas y su tipo
View(base)      # abre la base como hoja de cálculo dentro de RStudio

# --- 2. Todas las tablas de resultados ---------------------------------------
# Quedan en una lista llamada "tablas"; cada elemento lleva el nombre del CSV.
archivos <- list.files("output/tablas", pattern = "\\.csv$", full.names = TRUE)
tablas <- lapply(archivos, read_csv, show_col_types = FALSE)
names(tablas) <- tools::file_path_sans_ext(basename(archivos))
names(tablas)   # muestra qué tablas hay

# Fase 1
View(tablas$validaciones)               # chequeos de consistencia
View(tablas$inventario_cobertura)       # partidos disponibles por temporada, casa y momento
View(tablas$margen_resumen_global)      # margen medio, mediana, dispersión
View(tablas$margen_comparaciones)       # diferencias de margen con IC 95 %
# Fase 2
View(tablas$normalizacion_parametros)   # z de Shin y k de potencia
View(tablas$normalizacion_sensibilidad) # cuánto cambian las probabilidades entre métodos
# Fase 3
View(tablas$calibracion_curvas)         # desviación por intervalo con IC de Wilson
View(tablas$calibracion_ece_vs_azar)    # error de calibración frente al azar
View(tablas$puntuaciones)               # Brier y RPS frente a las líneas base
View(tablas$murphy)                     # fiabilidad, resolución, incertidumbre
View(tablas$hosmer_lemeshow)            # prueba por desenlace y número de grupos
# Fase 4
View(tablas$flb_pendiente)              # pendiente de calibración (sesgo favorito-longshot)
View(tablas$flb_por_rango)              # desviación en longshots, intermedios y favoritos
View(tablas$comparaciones_calibracion)  # Bet365 vs Pinnacle y apertura vs cierre
View(tablas$sensibilidad_comparaciones) # lo mismo sin la temporada 2020-21

# --- 3. Datos originales consolidados (opcional) ------------------------------
# Los 6 CSV de Football-Data unidos, una fila por partido (formato ancho).
for (f in sort(list.files("R", pattern = "\\.R$", full.names = TRUE))) {
  source(f, encoding = "UTF-8")
}
cfg <- read_yaml("config.yml")
partidos <- cargar_datos(cfg)$partidos
View(partidos)

# --- 4. Figuras y reporte ------------------------------------------------------
# El reporte completo (Fase 5) se abre en el navegador:
browseURL(normalizePath("output/reporte_calibracion.html"))

# Se abren con el visor de imágenes del computador. También pueden abrirse
# haciendo clic en output/figuras desde el panel "Files" de RStudio.
for (f in list.files("output/figuras", pattern = "\\.png$", full.names = TRUE)) {
  browseURL(normalizePath(f))
}

# --- 5. Ejemplos rápidos para explorar ----------------------------------------
# Cuántos partidos hay por casa y momento en la muestra
base %>% filter(en_muestra) %>% count(casa, momento)

# Verificar a mano un partido: Liverpool vs Norwich, temporada 2019-20
base %>%
  filter(local == "Liverpool", visitante == "Norwich", temporada == "2019-20") %>%
  select(fecha, casa, momento, cuota_H, cuota_D, cuota_A, margen_pp)

# Margen medio por temporada y casa (solo apertura)
base %>%
  filter(en_muestra, momento == "apertura") %>%
  group_by(temporada, casa) %>%
  summarise(margen_medio = mean(margen_pp), .groups = "drop")
