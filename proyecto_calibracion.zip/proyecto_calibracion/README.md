# ¿Están bien calibradas las casas de apuestas?

Proyecto 2 · Estadística Industrial · Universidad del Magdalena.

Evaluación **retrospectiva** de las probabilidades implícitas en las cuotas 1X2 de Pinnacle (casa sharp) y Bet365 (casa recreativa) para la Premier League inglesa, temporadas 2019-20 a 2024-25. Es un ejercicio académico de auditoría de pronósticos sobre datos históricos ya cerrados. No es, ni puede usarse como, una estrategia o recomendación de apuestas.

## Cómo ejecutar

Requisitos: R ≥ 4.2 y los paquetes `dplyr`, `tidyr`, `readr`, `purrr`, `lubridate`, `ggplot2`, `yaml` y, para el reporte, `rmarkdown`.

```r
install.packages(c("dplyr", "tidyr", "readr", "purrr", "lubridate", "ggplot2", "yaml", "rmarkdown"))
```

Abrir `proyecto_calibracion.Rproj` en RStudio y ejecutar:

```r
source("run_all.R")
```

El flujo completo (cinco fases y reporte) tarda unos 20 segundos y sobrescribe `output/` y `data/processed/`. Desde una terminal: `Rscript run_all.R` (el reporte necesita pandoc, que RStudio ya incluye).

## Ejecutar en otro computador

1. Descomprimir el proyecto en cualquier carpeta. Si Windows crea una carpeta dentro de otra con el mismo nombre, usar la de adentro (la que tiene `config.yml`).
2. Elegir una forma de ejecución:
   - **RStudio:** abrir `proyecto_calibracion.Rproj` y escribir `source("run_all.R")` en la **Consola**.
   - **Terminal** (pestaña *Terminal* de RStudio o la del sistema): `Rscript run_all.R` desde la carpeta del proyecto, o `Rscript "C:/ruta/al/proyecto/run_all.R"` desde cualquier carpeta. `Rscript` no se escribe en la Consola de R.
3. Si la Terminal de Windows no reconoce `Rscript`, usar la ruta completa: `"C:\Program Files\R\R-4.6.1\bin\Rscript.exe" run_all.R` (cambiar la versión por la instalada).

`run_all.R` encuentra solo la carpeta del proyecto y, si faltan paquetes, los instala. Si en algún equipo no la encuentra, escribir la ruta en la variable `RUTA_PROYECTO` al inicio de `run_all.R`, o definir la variable de entorno `PROYECTO_CALIBRACION`. Las rutas de datos y resultados están en `config.yml` (bloque `rutas`): relativas al proyecto por defecto, o absolutas si los datos están en otro disco.

Para que cada ejecución empiece en una sesión limpia: borrar el archivo `.RData` de la carpeta del proyecto, si existe, y en RStudio poner *Tools → Global Options → General → Restore .RData into workspace at startup* en **Never**.

## Estructura

```
config.yml                      Parámetros: liga, temporadas, casas, métodos, intervalos, semilla
run_all.R                       Script maestro: ejecuta las cinco fases y genera el reporte
explorar_resultados.R           Abre en RStudio la base, las tablas y las figuras
R/00_utils.R                    Paquetes y funciones auxiliares (Wilson, bootstrap por bloques)
R/01_cargar.R                   Fase 1 · lectura y consolidación de los CSV
R/02_validar.R                  Fase 1 · validaciones de consistencia
R/03_inventario.R               Fase 1 · formato largo, exclusiones, muestra apareada
R/04_margen.R                   Fase 1 · probabilidades brutas y margen
R/05_normalizar.R               Fase 2 · remoción del margen (multiplicativo, Shin, potencia)
R/06_calibracion.R              Fase 3 · curvas, Wilson, Brier, RPS, Murphy, Hosmer-Lemeshow
R/07_desviaciones.R             Fase 4 · favorito-longshot, casas, apertura/cierre, temporadas
reporte/reporte_calibracion.Rmd Fase 5 · reporte autogenerado
data/raw/                       CSV originales de Football-Data (E0_*)
data/processed/                 base_analitica.csv (entregable 1)
output/tablas/                  Todas las tablas de resultados
output/figuras/                 Figuras 1 a 11
output/reporte_calibracion.html Reporte de calibración (entregable 3)
```

## Cambiar de liga, temporadas o casas

Solo se edita `config.yml`. Para agregar una temporada se añade su año de inicio en `temporadas` y se coloca el CSV en `data/raw` como `<prefijo>_<año>-<año+1>.csv`. Para cambiar de liga se edita el bloque `ligas`. Con `descargar: true` el script intenta bajar los archivos faltantes y registra la fecha de descarga.

## Decisiones metodológicas

| Decisión | Justificación |
|---|---|
| Ventana 2019-20 a 2024-25 | Ambas casas tienen apertura y cierre; recolección homogénea; anterior a la advertencia sobre Pinnacle (23-07-2025). |
| Solo Premier League | Coherencia del alcance sobre su amplitud; evita mezclar ligas con tasas base distintas. La variación del margen entre ligas no se estudia. |
| Fechas con `lubridate::dmy()` | Lectura explícita día/mes/año; acepta años de 2 y 4 dígitos. |
| Muestra apareada | Un partido entra solo si las cuatro combinaciones casa × momento tienen mercado válido. |
| Tres métodos de remoción | Multiplicativo (principal), Shin y potencia (sensibilidad). Ninguna comparación usa probabilidades brutas. |
| Tres desenlaces agrupados en la curva | Cubre todo el rango de probabilidad; se verifica cada desenlace por separado (figura 8). |
| 10 intervalos de igual frecuencia | Cada intervalo con ≈684 predicciones; se verifica con 5 y 20 intervalos y con intervalos de igual ancho. |
| Intervalos de Wilson | Preferibles a la aproximación normal cerca de 0 y 1. |
| Líneas base | Uniforme (1/3) y frecuencia histórica de la muestra (exigente, porque usa los mismos datos). |
| Hosmer-Lemeshow con gl = g | Validación externa: las probabilidades no se estimaron con estos datos. Se reporta con 5, 10 y 20 grupos y junto a la magnitud en pp. |
| ECE frente al azar | Se simula cuánta desviación aparece con probabilidades perfectas, para distinguir error real de ruido. |
| Bootstrap por bloques de fecha | Respeta la dependencia entre partidos del mismo día y, con la misma matriz de pesos para ambas casas, el diseño apareado. |
| Pendiente de calibración con EE robusto por fecha | Contraste formal del sesgo favorito-longshot (b > 1). |
| Holm por familia | Familia confirmatoria: 12 contrastes (Brier, RPS, ECE × casas en apertura y cierre, apertura vs cierre en cada casa) con el método principal; 4 pendientes. |
| Sensibilidad sin 2020-21 | Temporada sin público; se repite lo confirmatorio sin ella. |

## Bitácora de uso de IA

Se entrega aparte, en `Bitacora_de_IA_final.xlsx` (entregable 6).

## Fuente de datos

Football-Data.co.uk (https://www.football-data.co.uk). Documentación de columnas en https://www.football-data.co.uk/notes.txt. Fecha de descarga: 12 de septiembre de 2026.
