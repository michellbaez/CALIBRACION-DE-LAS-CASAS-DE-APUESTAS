# =============================================================================
# 01_cargar.R · Carga y consolidación de los CSV de Football-Data
# =============================================================================

# Descarga opcional de una temporada (solo si descargar = true en config.yml)
descargar_temporada <- function(codigo, anio, destino, cfg) {
  url <- sprintf("https://www.football-data.co.uk/mmz4281/%02d%02d/%s.csv",
                 anio %% 100, (anio + 1) %% 100, codigo)
  message("   Descargando ", url)
  utils::download.file(url, destino, mode = "wb", quiet = TRUE)
  registro <- file.path(cfg$rutas$datos_crudos, "registro_descargas.csv")
  fila <- tibble(archivo = basename(destino), url = url,
                 fecha_descarga = format(Sys.time(), "%Y-%m-%d %H:%M:%S"))
  write_csv(fila, registro, append = file.exists(registro))
}

# Lee un archivo de temporada. Todo se lee como texto y se convierte de forma
# explícita: la fecha con dmy() (día/mes/año, sirve para años de 2 y 4
# dígitos) y las cuotas con as.numeric().
leer_temporada <- function(ruta, liga, codigo, anio, cols_cuotas) {
  df <- read_csv(ruta, col_types = cols(.default = col_character()),
                 na = c("", "NA"), show_col_types = FALSE, progress = FALSE)

  # Algunos archivos traen filas finales vacías
  df <- filter(df, !is.na(HomeTeam), HomeTeam != "")

  # No asumir que todas las columnas existen en todas las temporadas
  ausentes <- setdiff(cols_cuotas, names(df))
  for (col in ausentes) df[[col]] <- NA_character_
  if (!"Div" %in% names(df)) df$Div <- NA_character_

  # Cuotas con texto no numérico (se cuentan antes de convertir)
  no_numericas <- sum(vapply(cols_cuotas, function(col) {
    x <- df[[col]]
    sum(!is.na(x) & is.na(suppressWarnings(as.numeric(x))))
  }, numeric(1)))

  datos <- df %>%
    mutate(fila_archivo = row_number()) %>%
    transmute(
      partido_id      = sprintf("%s_%s_%03d", codigo, etiqueta_temporada(anio), fila_archivo),
      liga            = liga,
      codigo_esperado = codigo,
      div_archivo     = Div,
      anio_inicio     = anio,
      temporada       = etiqueta_temporada(anio),
      fecha_texto     = Date,
      fecha           = dmy(Date, quiet = TRUE),
      local           = HomeTeam,
      visitante       = AwayTeam,
      goles_local     = suppressWarnings(as.integer(FTHG)),
      goles_visitante = suppressWarnings(as.integer(FTAG)),
      resultado       = FTR,
      across(all_of(cols_cuotas), ~ suppressWarnings(as.numeric(.x)))
    )

  registro <- tibble(
    liga = liga, temporada = etiqueta_temporada(anio), archivo = basename(ruta),
    filas = nrow(datos),
    columnas_ausentes = if (length(ausentes)) paste(ausentes, collapse = " ") else "",
    cuotas_no_numericas = no_numericas
  )
  list(datos = datos, registro = registro)
}

cargar_datos <- function(cfg) {
  ligas <- tabla_ligas(cfg)
  casas <- tabla_casas(cfg)
  cols  <- columnas_cuotas(casas$prefijo, unlist(cfg$momentos))
  dir.create(cfg$rutas$datos_crudos, recursive = TRUE, showWarnings = FALSE)

  combinaciones <- expand_grid(ligas, anio = unlist(cfg$temporadas))

  resultados <- pmap(combinaciones, function(liga, codigo, prefijo_archivo,
                                             partidos_esperados, anio) {
    ruta <- file.path(cfg$rutas$datos_crudos, nombre_archivo(prefijo_archivo, anio))
    if (!file.exists(ruta)) {
      if (isTRUE(cfg$descargar)) {
        descargar_temporada(codigo, anio, ruta, cfg)
      } else {
        stop("No existe ", ruta, ". Copie el archivo a ", cfg$rutas$datos_crudos,
             " o ponga 'descargar: true' en config.yml.", call. = FALSE)
      }
    }
    leer_temporada(ruta, liga, codigo, anio, cols)
  })

  partidos <- bind_rows(map(resultados, "datos"))
  registro <- bind_rows(map(resultados, "registro"))
  message(sprintf("   %d archivos leídos, %d partidos en total", nrow(registro), nrow(partidos)))
  list(partidos = partidos, registro = registro)
}
