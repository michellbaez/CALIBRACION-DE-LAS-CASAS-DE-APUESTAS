# =============================================================================
# 03_inventario.R · Formato largo, reglas de exclusión e inventario de cobertura
# =============================================================================

# Una fila por partido x casa x momento, con sus tres cuotas y la regla de
# exclusión que aplique (si aplica).
cuotas_largo <- function(partidos, cfg) {
  casas <- tabla_casas(cfg)
  combinaciones <- expand_grid(casas, momento = unlist(cfg$momentos))

  pmap_dfr(combinaciones, function(casa, prefijo, fecha_corte, momento) {
    p <- prefijo_columnas(prefijo, momento)
    partidos %>%
      transmute(partido_id, liga, temporada, anio_inicio, fecha, local, visitante,
                goles_local, goles_visitante, resultado,
                casa = casa, momento = momento,
                cuota_H = .data[[paste0(p, "H")]],
                cuota_D = .data[[paste0(p, "D")]],
                cuota_A = .data[[paste0(p, "A")]],
                fecha_corte = fecha_corte)
  }) %>%
    mutate(
      motivo_exclusion = case_when(
        is.na(cuota_H) | is.na(cuota_D) | is.na(cuota_A) ~ "cuota faltante",
        cuota_H <= 1 | cuota_D <= 1 | cuota_A <= 1       ~ "cuota <= 1 (imposible)",
        !is.na(fecha_corte) & fecha >= fecha_corte       ~ "posterior a fecha de corte declarada por la fuente",
        TRUE ~ NA_character_
      ),
      mercado_valido = is.na(motivo_exclusion)
    ) %>%
    select(-fecha_corte)
}

# Diseño apareado: un partido entra a la muestra analítica solo si TODAS las
# combinaciones casa x momento tienen mercado válido. Así cada comparación
# entre casas o entre apertura y cierre se hace sobre exactamente los mismos
# partidos.
marcar_muestra <- function(largo) {
  n_combinaciones <- n_distinct(paste(largo$casa, largo$momento))
  completos <- largo %>%
    group_by(partido_id) %>%
    summarise(completo = sum(mercado_valido) == n_combinaciones, .groups = "drop")

  largo %>%
    left_join(completos, by = "partido_id") %>%
    mutate(
      en_muestra = completo,
      motivo_exclusion = if_else(
        mercado_valido & !completo,
        "otra casa o momento sin mercado valido (diseno apareado)",
        motivo_exclusion
      )
    ) %>%
    select(-completo)
}

construir_inventario <- function(largo) {
  largo %>%
    group_by(liga, temporada, casa, momento) %>%
    summarise(
      partidos_en_archivo        = n(),
      con_mercado_completo       = sum(mercado_valido),
      excl_cuota_faltante        = sum(motivo_exclusion %in% "cuota faltante"),
      excl_cuota_imposible       = sum(motivo_exclusion %in% "cuota <= 1 (imposible)"),
      excl_posterior_corte       = sum(grepl("corte", motivo_exclusion)),
      excl_por_apareamiento      = sum(grepl("apareado", motivo_exclusion)),
      en_muestra_analitica       = sum(en_muestra),
      .groups = "drop"
    ) %>%
    mutate(cobertura_pct = round(100 * con_mercado_completo / partidos_en_archivo, 1))
}

listar_exclusiones <- function(largo) {
  largo %>%
    filter(!en_muestra) %>%
    select(partido_id, liga, temporada, fecha, local, visitante,
           casa, momento, motivo_exclusion) %>%
    arrange(liga, temporada, fecha, partido_id, casa, momento)
}

resumen_muestra <- function(largo) {
  largo %>%
    distinct(partido_id, liga, temporada, en_muestra) %>%
    group_by(liga, temporada) %>%
    summarise(partidos_en_archivo = n(),
              partidos_en_muestra = sum(en_muestra),
              partidos_excluidos  = sum(!en_muestra),
              .groups = "drop")
}
