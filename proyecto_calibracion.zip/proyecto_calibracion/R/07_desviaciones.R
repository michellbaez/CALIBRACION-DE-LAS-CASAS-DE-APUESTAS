# =============================================================================
# 07_desviaciones.R · Fase 4: desviaciones sistemáticas
#
#   1. Sesgo favorito-longshot: pendiente de calibración y desviación por
#      rango de probabilidad (longshot, intermedio, favorito).
#   2. Operador: Bet365 frente a Pinnacle sobre los mismos partidos.
#   3. Momento: apertura frente a cierre (incorporación de información).
#   4. Tiempo: métricas por temporada y calibración de la victoria local.
#   5. Sensibilidad: todo lo confirmatorio repetido sin 2020-21.
#
# Inferencia: los partidos se remuestrean por FECHA (bootstrap por bloques)
# con una misma matriz de pesos para las dos casas o los dos momentos, lo que
# respeta a la vez el diseño apareado y la dependencia entre partidos del
# mismo día.
# =============================================================================

# --- 1a. Pendiente de calibración ----------------------------------------------
# Regresión logística: logit P(y = 1) = a + b * logit(p).
#   b = 1  probabilidades bien escaladas
#   b > 1  la realidad es más extrema que la cuota: los favoritos ganan más y
#          los longshots menos de lo que dice la cuota (sesgo favorito-longshot)
#   b < 1  lo contrario
# Los errores estándar son robustos por conglomerado (fecha): el modelo
# "ingenuo" supone predicciones independientes, y no lo son (las tres de un
# partido suman 1 y los partidos del mismo día comparten condiciones).
pendiente_calibracion <- function(pred, cfg) {
  z <- qnorm(1 - (1 - cfg$inferencia$nivel_confianza) / 2)
  pred %>%
    group_by(across(all_of(grupos_base))) %>%
    group_modify(function(d, clave) {
      x <- qlogis(d$p)
      ajuste <- glm(d$y ~ x, family = binomial())
      X  <- model.matrix(ajuste)
      mu <- fitted(ajuste)
      pan <- solve(crossprod(X, X * (mu * (1 - mu))))   # (X' W X)^-1
      Ug  <- rowsum(X * (d$y - mu), d$fecha)            # score sumado por fecha
      G   <- nrow(Ug)
      V   <- pan %*% crossprod(Ug) %*% pan * G / (G - 1)
      b   <- unname(coef(ajuste))
      ee  <- sqrt(diag(V))
      tibble(intercepto = b[1], pendiente = b[2],
             ee_robusto = ee[2], ee_ingenuo = sqrt(diag(vcov(ajuste)))[2],
             ic_inf = b[2] - z * ee[2], ic_sup = b[2] + z * ee[2],
             p_valor_b_igual_1 = 2 * pnorm(-abs((b[2] - 1) / ee[2])))
    }) %>%
    ungroup() %>%
    group_by(liga, metodo) %>%
    mutate(p_holm = p.adjust(p_valor_b_igual_1, method = "holm")) %>%
    ungroup() %>%
    mutate(p_holm_texto = formato_p(p_holm),
           confirmatorio = metodo == cfg$normalizacion$metodo_principal) %>%
    redondear(4)
}

# --- 1b. Desviación por rango de probabilidad ------------------------------------
# Compara los extremos: ¿los longshots ocurren menos de lo que dice la cuota y
# los favoritos más? Magnitud en pp, con IC bootstrap por fecha.
desviacion_por_rango <- function(pred, cfg) {
  cortes <- unlist(cfg$desviaciones$cortes_rango)
  etiquetas <- unlist(cfg$desviaciones$etiquetas_rango)
  B <- cfg$inferencia$n_bootstrap
  a <- (1 - cfg$inferencia$nivel_confianza) / 2

  map_dfr(unique(pred$liga), function(lg) {
    d0 <- pred %>%
      filter(liga == lg) %>%
      mutate(rango = cut(p, cortes, labels = etiquetas, include.lowest = TRUE, right = FALSE),
             bloque = as.integer(factor(fecha)))
    K <- max(d0$bloque)
    W <- generar_pesos_bootstrap(K, B)

    d0 %>%
      group_by(across(all_of(grupos_base))) %>%
      group_modify(function(d, clave) {
        df <- data.frame(bloque = factor(d$bloque, levels = seq_len(K)),
                         rango = d$rango, p = d$p, y = d$y)
        Mn <- unclass(xtabs(~ bloque + rango, df))
        Mp <- unclass(xtabs(p ~ bloque + rango, df))
        My <- unclass(xtabs(y ~ bloque + rango, df))
        dev_bs <- 100 * (W %*% (My - Mp)) / (W %*% Mn)
        n <- colSums(Mn)
        tibble(rango = factor(colnames(Mn), levels = etiquetas),
               n = n,
               p_media = colSums(Mp) / n,
               frec_obs = colSums(My) / n,
               desviacion_pp = 100 * (frec_obs - p_media),
               ic_inf_pp = apply(dev_bs, 2, quantile, a),
               ic_sup_pp = apply(dev_bs, 2, quantile, 1 - a),
               p_bootstrap = 2 * pnorm(-abs(desviacion_pp) / apply(dev_bs, 2, sd)))
      }) %>%
      ungroup()
  }) %>%
    redondear(4)
}

# --- 2 y 3. Contrastes apareados: casas y momentos -------------------------------
# ECE de un grupo para todas las réplicas bootstrap a la vez. Los intervalos
# se fijan con la muestra completa; en cada réplica cambian los pesos.
ece_bootstrap <- function(d, fechas, W, esquema, k) {
  df <- data.frame(bloque = factor(match(d$fecha, fechas), levels = seq_along(fechas)),
                   intervalo = asignar_intervalos(d$p, esquema, k),
                   p = d$p, y = d$y)
  Mn <- unclass(xtabs(~ bloque + intervalo, df))
  Md <- unclass(xtabs(I(y - p) ~ bloque + intervalo, df))
  list(obs = 100 * sum(abs(colSums(Md))) / nrow(df),
       bs  = 100 * rowSums(abs(W %*% Md)) / rowSums(W %*% Mn))
}

# Familia confirmatoria (por liga y método):
#   Entre casas:        casa1 - casa2, en apertura y en cierre
#   Apertura vs cierre: apertura - cierre, para cada casa
# Métricas: Brier, RPS (diferencia por partido) y ECE en pp.
# Diferencia POSITIVA = el primer término tiene MÁS error.
comparaciones_calibracion <- function(pred, metricas, cfg, metodos = NULL) {
  casas    <- tabla_casas(cfg)$casa
  momentos <- unlist(cfg$momentos)
  esquema  <- cfg$calibracion$esquema_principal
  k        <- cfg$calibracion$n_intervalos
  B        <- cfg$inferencia$n_bootstrap
  a        <- (1 - cfg$inferencia$nivel_confianza) / 2
  if (is.null(metodos)) metodos <- unique(metricas$metodo)

  contrastes <- bind_rows(
    if (length(casas) == 2)
      tibble(familia = "Entre casas", a_casa = casas[1], a_mom = momentos,
             b_casa = casas[2], b_mom = momentos,
             contraste = paste0(casas[1], " - ", casas[2], " (", momentos, ")")),
    if (all(c("apertura", "cierre") %in% momentos))
      tibble(familia = "Apertura vs cierre", a_casa = casas, a_mom = "apertura",
             b_casa = casas, b_mom = "cierre",
             contraste = paste0("apertura - cierre (", casas, ")"))
  )

  map_dfr(unique(metricas$liga), function(lg) {
    m  <- filter(metricas, liga == lg)
    pr <- filter(pred, liga == lg)
    fechas <- sort(unique(m$fecha))
    W <- generar_pesos_bootstrap(length(fechas), B)

    map_dfr(metodos, function(me) {
      map_dfr(seq_len(nrow(contrastes)), function(i) {
        ct <- contrastes[i, ]
        A  <- m %>% filter(metodo == me, casa == ct$a_casa, momento == ct$a_mom) %>% arrange(partido_id)
        Bm <- m %>% filter(metodo == me, casa == ct$b_casa, momento == ct$b_mom) %>% arrange(partido_id)
        stopifnot(identical(A$partido_id, Bm$partido_id))   # diseño apareado
        idx <- match(A$fecha, fechas)

        filas <- map_dfr(c("brier", "rps"), function(met) {
          dif <- A[[met]] - Bm[[met]]
          bs  <- media_bootstrap(dif, idx, W)
          tibble(metrica = met, valor_a = mean(A[[met]]), valor_b = mean(Bm[[met]]),
                 diferencia = mean(dif),
                 ic_inf = unname(quantile(bs, a)), ic_sup = unname(quantile(bs, 1 - a)),
                 p_bootstrap = p_bootstrap(bs, mean(dif)),
                 p_wilcoxon = wilcox.test(dif, mu = 0, exact = FALSE)$p.value)
        })

        ea <- ece_bootstrap(filter(pr, metodo == me, casa == ct$a_casa, momento == ct$a_mom),
                            fechas, W, esquema, k)
        eb <- ece_bootstrap(filter(pr, metodo == me, casa == ct$b_casa, momento == ct$b_mom),
                            fechas, W, esquema, k)
        bs <- ea$bs - eb$bs
        filas <- bind_rows(filas, tibble(
          metrica = "ece_pp", valor_a = ea$obs, valor_b = eb$obs, diferencia = ea$obs - eb$obs,
          ic_inf = unname(quantile(bs, a)), ic_sup = unname(quantile(bs, 1 - a)),
          p_bootstrap = p_bootstrap(bs, ea$obs - eb$obs), p_wilcoxon = NA_real_))

        filas %>% mutate(liga = lg, metodo = me, familia = ct$familia,
                         contraste = ct$contraste, n_partidos = nrow(A), .before = 1)
      })
    })
  }) %>%
    group_by(liga, metodo) %>%
    mutate(p_holm = p.adjust(p_bootstrap, method = "holm")) %>%
    ungroup() %>%
    mutate(p_holm_texto = formato_p(p_holm),
           confirmatorio = metodo == cfg$normalizacion$metodo_principal) %>%
    mutate(across(c(valor_a, valor_b, diferencia, ic_inf, ic_sup), ~ round(.x, 5)))
}

# --- 4. Evolución temporal ---------------------------------------------------------
# Brier y RPS por temporada (método principal) y diferencia entre casas por
# temporada con IC. Descriptivo: sin valores p, para no multiplicar contrastes.
por_temporada <- function(metricas, cfg) {
  principal <- cfg$normalizacion$metodo_principal
  casas <- tabla_casas(cfg)$casa
  B <- cfg$inferencia$n_bootstrap
  a <- (1 - cfg$inferencia$nivel_confianza) / 2
  m <- filter(metricas, metodo == principal)

  niveles <- m %>%
    group_by(liga, temporada, casa, momento) %>%
    summarise(n_partidos = n(), brier = mean(brier), rps = mean(rps), .groups = "drop")

  if (length(casas) != 2) return(list(niveles = redondear(niveles, 4), diferencias = tibble()))

  diferencias <- m %>%
    select(liga, temporada, fecha, partido_id, casa, momento, brier) %>%
    pivot_wider(names_from = casa, values_from = brier) %>%
    mutate(dif = .data[[casas[1]]] - .data[[casas[2]]]) %>%
    group_by(liga, temporada, momento) %>%
    group_modify(function(d, clave) {
      bs <- boot_media_bloques(d$dif, d$fecha, B)
      tibble(contraste = paste(casas[1], "-", casas[2]),
             dif_brier = mean(d$dif),
             ic_inf = unname(quantile(bs, a)), ic_sup = unname(quantile(bs, 1 - a)))
    }) %>%
    ungroup()

  list(niveles = redondear(niveles, 4), diferencias = redondear(diferencias, 5))
}

# --- Figuras de la Fase 4 ----------------------------------------------------------
graficar_desviaciones <- function(rangos, comparaciones, pendientes, grueso_temp,
                                  niveles_temp, cfg) {
  dir_fig <- cfg$rutas$figuras
  principal <- cfg$normalizacion$metodo_principal
  subt <- subtitulo_alcance(cfg)
  pd <- position_dodge(width = 0.5)

  # Figura 9: desviación por rango, para cada método (el sesgo depende del método)
  g9 <- ggplot(rangos, aes(x = rango, y = desviacion_pp, color = casa)) +
    geom_hline(yintercept = 0, linetype = 2, color = "grey50") +
    geom_errorbar(aes(ymin = ic_inf_pp, ymax = ic_sup_pp), width = 0.15, position = pd) +
    geom_point(size = 2, position = pd) +
    facet_grid(metodo ~ momento) +
    labs(title = "Sesgo favorito-longshot: desviación por rango de probabilidad",
         subtitle = paste0(subt, "\nlongshot < 0.20 ≤ intermedio < 0.60 ≤ favorito · IC 95 % bootstrap por fecha"),
         x = NULL, y = "Frecuencia observada menos probabilidad (pp)", color = NULL) +
    tema_proyecto()
  ggsave(file.path(dir_fig, "fig9_sesgo_favorito_longshot.png"), g9,
         width = 9, height = 7.5, dpi = 150, bg = "white")

  # Figura 10: contrastes de la familia confirmatoria, para cada método
  etiquetas_met <- c(brier = "Brier", rps = "RPS", ece_pp = "ECE (pp)")
  metodos <- unique(comparaciones$metodo)
  cmp <- comparaciones %>%
    mutate(metrica = factor(etiquetas_met[metrica], levels = etiquetas_met),
           y_base = as.integer(factor(contraste)),
           y_graf = y_base + (match(metodo, metodos) - (length(metodos) + 1) / 2) * 0.22)
  niveles_y <- levels(factor(cmp$contraste))
  g10 <- ggplot(cmp, aes(x = diferencia, y = y_graf, color = metodo)) +
    geom_vline(xintercept = 0, linetype = 2, color = "grey50") +
    geom_errorbar(aes(xmin = ic_inf, xmax = ic_sup), width = 0.15, orientation = "y") +
    geom_point(size = 1.8) +
    scale_y_continuous(breaks = seq_along(niveles_y), labels = niveles_y) +
    scale_x_continuous(n.breaks = 4) +
    facet_wrap(~ metrica, scales = "free_x") +
    labs(title = "Diferencias de precisión y calibración, con IC 95 % (bootstrap por fecha)",
         subtitle = paste0(subt, "\nDiferencia positiva = el primer término tiene más error"),
         x = "Diferencia", y = NULL, color = "Método") +
    tema_proyecto() + theme(panel.spacing.x = unit(1.5, "lines"))
  ggsave(file.path(dir_fig, "fig10_comparaciones_calibracion.png"), g10,
         width = 10, height = 5, dpi = 150, bg = "white")

  # Figura 11: victoria local observada frente a predicha, y Brier, por temporada
  local <- grueso_temp %>%
    filter(desenlace == "Local", momento == "apertura") %>%
    select(temporada, casa, p_media, frec_obs)
  paneles <- c("Victoria local (%): observada y predicha por cada casa", "Brier (menor es mejor)")
  serie_local <- bind_rows(
    local %>% distinct(temporada, frec_obs) %>% transmute(temporada, serie = "Observada", valor = 100 * frec_obs),
    local %>% transmute(temporada, serie = casa, valor = 100 * p_media)
  ) %>% mutate(panel = paneles[1])
  serie_brier <- niveles_temp %>%
    filter(momento == "apertura") %>%
    transmute(temporada, serie = casa, valor = brier, panel = paneles[2])
  casas <- sort(unique(local$casa))
  colores <- c(setNames(scales::hue_pal()(length(casas)), casas), Observada = "black")
  g11 <- ggplot(bind_rows(serie_local, serie_brier) %>% mutate(panel = factor(panel, levels = paneles)),
                aes(x = temporada, y = valor, color = serie, group = serie)) +
    geom_line() + geom_point() +
    scale_color_manual(values = colores) +
    facet_wrap(~ panel, ncol = 1, scales = "free_y") +
    labs(title = "Evolución por temporada (cuotas de apertura)",
         subtitle = paste0(subt, " · método ", principal, "\n2020-21 se jugó sin público"),
         x = NULL, y = NULL, color = NULL) +
    tema_proyecto()
  ggsave(file.path(dir_fig, "fig11_evolucion_temporal.png"), g11,
         width = 9, height = 6.5, dpi = 150, bg = "white")

  invisible(list(g9, g10, g11))
}
