# =============================================================================
# 00_utils.R · Paquetes y funciones auxiliares compartidas
# =============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(purrr)
  library(lubridate)
  library(ggplot2)
  library(yaml)
})

# 2019 -> "2019-20"
etiqueta_temporada <- function(anio) sprintf("%d-%02d", anio, (anio + 1) %% 100)

# ("E0", 2019) -> "E0_2019-2020.csv"
nombre_archivo <- function(prefijo, anio) sprintf("%s_%d-%d.csv", prefijo, anio, anio + 1)

# Prefijo de columnas según el momento: apertura "B365", cierre "B365C"
prefijo_columnas <- function(prefijo_casa, momento) {
  if (identical(momento, "cierre")) paste0(prefijo_casa, "C") else prefijo_casa
}

# Todas las columnas de cuotas 1X2 que pide la configuración
columnas_cuotas <- function(prefijos_casa, momentos) {
  unlist(lapply(prefijos_casa, function(p) {
    lapply(momentos, function(m) paste0(prefijo_columnas(p, m), c("H", "D", "A")))
  }))
}

# Tablas de configuración en formato tibble
tabla_ligas <- function(cfg) {
  map_dfr(cfg$ligas, ~ tibble(
    liga               = .x$nombre,
    codigo             = .x$codigo,
    prefijo_archivo    = .x$prefijo_archivo,
    partidos_esperados = as.integer(.x$partidos_esperados)
  ))
}

tabla_casas <- function(cfg) {
  map_dfr(cfg$casas, ~ tibble(
    casa        = .x$nombre,
    prefijo     = .x$prefijo,
    fecha_corte = if (is.null(.x$fecha_corte)) as.Date(NA) else as.Date(.x$fecha_corte)
  ))
}

# Bootstrap por bloques (conglomerados) de la media.
# Se remuestrean bloques completos (aquí: fechas de partido), no partidos
# sueltos, para respetar la dependencia entre partidos jugados el mismo día.
boot_media_bloques <- function(x, bloque, B) {
  s <- tapply(x, bloque, sum)
  n <- tapply(x, bloque, length)
  k <- length(s)
  replicate(B, {
    i <- sample.int(k, k, replace = TRUE)
    sum(s[i]) / sum(n[i])
  })
}

# Redondeo de todas las columnas numéricas decimales de una tabla
redondear <- function(df, digitos = 3) {
  mutate(df, across(where(is.double), ~ round(.x, digitos)))
}

# --- Auxiliares de las Fases 2 a 4 ------------------------------------------

# Intervalo de Wilson para una proporción x/n. Es preferible a la
# aproximación normal cuando la proporción está cerca de 0 o de 1.
wilson_ic <- function(x, n, nivel = 0.95) {
  z <- qnorm(1 - (1 - nivel) / 2)
  p <- x / n
  centro <- (p + z^2 / (2 * n)) / (1 + z^2 / n)
  radio  <- (z / (1 + z^2 / n)) * sqrt(p * (1 - p) / n + z^2 / (4 * n^2))
  list(inf = centro - radio, sup = centro + radio)
}

# Matriz de pesos para el bootstrap por bloques: B filas (réplicas) x K
# columnas (bloques). Cada fila dice cuántas veces salió cada bloque en esa
# réplica. Se genera UNA vez y se reutiliza en todos los contrastes, de modo
# que las casas y los momentos se remuestrean con los mismos partidos
# (diseño apareado) y los resultados son reproducibles.
generar_pesos_bootstrap <- function(K, B) {
  t(replicate(B, tabulate(sample.int(K, K, replace = TRUE), nbins = K)))
}

# Media por bloques para todas las réplicas a la vez: x es un valor por
# partido, bloque_idx el número de bloque (1..K) de cada partido.
media_bootstrap <- function(x, bloque_idx, W) {
  K <- ncol(W)
  s <- tabulate_suma(x, bloque_idx, K)
  n <- tabulate(bloque_idx, nbins = K)
  as.vector(W %*% s) / as.vector(W %*% n)
}

tabulate_suma <- function(x, idx, K) {
  out <- numeric(K)
  sumas <- rowsum(x, idx)
  out[as.integer(rownames(sumas))] <- sumas[, 1]
  out
}

# Valor p para H0: diferencia = 0, usando el error estándar bootstrap (la
# desviación estándar de las réplicas) y la aproximación normal. Es más
# estable que contar cuántas réplicas caen al otro lado del cero, porque no
# depende de unas pocas réplicas extremas.
p_bootstrap <- function(bs, estimacion) {
  2 * pnorm(-abs(estimacion) / sd(bs))
}

formato_p <- function(p) format.pval(p, digits = 2, eps = 0.001)

nombre_desenlace <- c(H = "Local", D = "Empate", A = "Visitante")

tema_proyecto <- function() {
  theme_minimal(base_size = 11) +
    theme(legend.position = "bottom", panel.grid.minor = element_blank())
}

subtitulo_alcance <- function(cfg) {
  temps <- unlist(cfg$temporadas)
  sprintf("%s · temporadas %s a %s",
          paste(tabla_ligas(cfg)$liga, collapse = " y "),
          etiqueta_temporada(min(temps)), etiqueta_temporada(max(temps)))
}

# Pandoc convierte el reporte a HTML. RStudio lo trae incluido, pero al usar
# Rscript desde una terminal R no siempre lo encuentra: se busca en las
# carpetas donde lo instalan RStudio y Quarto en Windows, macOS y Linux.
preparar_pandoc <- function() {
  if (rmarkdown::pandoc_available()) return(TRUE)
  base <- c(Sys.getenv("RSTUDIO_PANDOC"),
            "C:/Program Files/RStudio/resources/app/bin/quarto/bin/tools",
            "C:/Program Files/RStudio/bin/quarto/bin/tools",
            "C:/Program Files/RStudio/bin/pandoc",
            "C:/Program Files/Quarto/bin/tools",
            file.path(Sys.getenv("LOCALAPPDATA"), "Programs/RStudio/resources/app/bin/quarto/bin/tools"),
            "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/tools",
            "/Applications/RStudio.app/Contents/MacOS/quarto/bin/tools",
            "/Applications/RStudio.app/Contents/MacOS/pandoc",
            "/usr/lib/rstudio/resources/app/bin/quarto/bin/tools",
            "/usr/lib/rstudio/bin/quarto/bin/tools",
            "/opt/quarto/bin/tools")
  carpetas <- unique(c(base, file.path(base, "x86_64"), file.path(base, "aarch64")))
  carpetas <- carpetas[nzchar(carpetas) & dir.exists(carpetas)]
  for (d in carpetas) {
    if (file.exists(file.path(d, "pandoc")) || file.exists(file.path(d, "pandoc.exe"))) {
      Sys.setenv(RSTUDIO_PANDOC = d)
      rmarkdown::find_pandoc(cache = FALSE, dir = d)
      if (rmarkdown::pandoc_available()) return(TRUE)
    }
  }
  FALSE
}
