# =============================================================================
# 05_normalizar.R · Fase 2: remoción del margen
#
# Las probabilidades brutas (1/cuota) suman más de 1. Antes de compararlas con
# frecuencias observadas hay que repartir ese exceso entre los tres
# resultados. No se observa cómo lo repartió la casa, así que cada método
# encarna un supuesto distinto. Aquí se implementan tres:
#
#   multiplicativo  El margen se reparte en proporción a cada probabilidad.
#   shin            El margen protege a la casa de apostadores informados y
#                   recae más sobre los resultados improbables (longshots).
#   potencia        p_real = p_bruta^k, con k > 1 elegido para que sumen 1.
#
# Cada función recibe las tres probabilidades brutas de UN partido y devuelve
# las tres normalizadas (que suman 1) y el parámetro estimado, si lo hay.
# =============================================================================

normalizar_multiplicativo <- function(pi) {
  list(p = pi / sum(pi), parametro = NA_real_)
}

# Shin (1993): para un parámetro z (proporción de dinero informado),
#   p_i(z) = [ sqrt(z^2 + 4 (1 - z) pi_i^2 / S) - z ] / [ 2 (1 - z) ]
# con S = suma de las brutas. Se busca el z que hace sumar 1 a las p_i.
normalizar_shin <- function(pi) {
  S <- sum(pi)
  p_de_z <- function(z) (sqrt(z^2 + 4 * (1 - z) * pi^2 / S) - z) / (2 * (1 - z))
  f <- function(z) sum(p_de_z(z)) - 1
  # En z = 0 la suma es sqrt(S) > 1 y decrece con z: la raíz está en (0, 0.5)
  z <- uniroot(f, c(0, 0.5), tol = 1e-12)$root
  p <- p_de_z(z)
  list(p = p / sum(p), parametro = z)
}

# Potencia: se busca k tal que sum(pi^k) = 1. En k = 1 la suma es S > 1 y
# decrece al aumentar k, porque cada pi está entre 0 y 1.
normalizar_potencia <- function(pi) {
  f <- function(k) sum(pi^k) - 1
  k <- uniroot(f, c(1, 10), tol = 1e-12)$root
  p <- pi^k
  list(p = p / sum(p), parametro = k)
}

funciones_normalizacion <- list(
  multiplicativo = normalizar_multiplicativo,
  shin           = normalizar_shin,
  potencia       = normalizar_potencia
)

# Agrega a la base, para cada método, las columnas p_<metodo>_H/D/A y el
# parámetro estimado (param_<metodo>). Se resuelve partido por partido.
aplicar_normalizacion <- function(base, metodos) {
  desconocidos <- setdiff(metodos, names(funciones_normalizacion))
  if (length(desconocidos)) stop("Método no implementado: ", paste(desconocidos, collapse = ", "))

  brutas <- as.matrix(base[, c("pbruta_H", "pbruta_D", "pbruta_A")])
  validos <- which(base$mercado_valido)

  for (m in metodos) {
    fun <- funciones_normalizacion[[m]]
    P <- matrix(NA_real_, nrow(base), 3)
    parametro <- rep(NA_real_, nrow(base))
    for (i in validos) {
      r <- fun(brutas[i, ])
      P[i, ] <- r$p
      parametro[i] <- r$parametro
    }
    base[[paste0("p_", m, "_H")]] <- P[, 1]
    base[[paste0("p_", m, "_D")]] <- P[, 2]
    base[[paste0("p_", m, "_A")]] <- P[, 3]
    if (!all(is.na(parametro))) base[[paste0("param_", m)]] <- parametro
  }
  base
}

# Control de calidad: las normalizadas deben sumar 1 y estar entre 0 y 1
verificar_normalizacion <- function(base, metodos) {
  map_dfr(metodos, function(m) {
    P <- as.matrix(base[base$mercado_valido, paste0("p_", m, c("_H", "_D", "_A"))])
    tibble(metodo = m,
           max_error_suma = max(abs(rowSums(P) - 1)),
           min_prob = min(P), max_prob = max(P))
  })
}

# --- Formato largo de predicciones --------------------------------------------
# Una fila por partido x casa x momento x método x desenlace (H, D, A), con la
# probabilidad normalizada p y el indicador y (1 si ese desenlace ocurrió).
# Solo se usan probabilidades NORMALIZADAS: las brutas nunca entran aquí.
predicciones_largo <- function(base) {
  base %>%
    filter(en_muestra) %>%
    select(partido_id, liga, temporada, anio_inicio, fecha, casa, momento,
           resultado, matches("^p_.+_[HDA]$")) %>%
    pivot_longer(matches("^p_.+_[HDA]$"),
                 names_to = c("metodo", "desenlace"),
                 names_pattern = "^p_(.+)_([HDA])$",
                 values_to = "p") %>%
    mutate(y = as.integer(resultado == desenlace))
}

# --- Sensibilidad entre métodos ------------------------------------------------
# Para cada método distinto del principal: diferencia (en pp) entre su
# probabilidad y la del método principal, según el rango de probabilidad.
# Muestra DÓNDE se separan los métodos (favoritos vs longshots).
sensibilidad_metodos <- function(pred, cfg) {
  principal <- cfg$normalizacion$metodo_principal
  ref <- pred %>% filter(metodo == principal) %>%
    select(partido_id, casa, momento, desenlace, p_ref = p)

  pred %>%
    filter(metodo != principal) %>%
    inner_join(ref, by = c("partido_id", "casa", "momento", "desenlace")) %>%
    mutate(rango_ref = cut(p_ref, breaks = c(0, 0.1, 0.2, 0.4, 0.6, 1),
                           include.lowest = TRUE, right = FALSE),
           dif_pp = 100 * (p - p_ref)) %>%
    group_by(liga, casa, momento, metodo, rango_ref) %>%
    summarise(n_predicciones = n(),
              dif_media_pp = mean(dif_pp),
              dif_min_pp = min(dif_pp),
              dif_max_pp = max(dif_pp),
              .groups = "drop") %>%
    mutate(comparado_con = principal) %>%
    redondear(3)
}

resumen_parametros <- function(base, metodos) {
  cols <- intersect(paste0("param_", metodos), names(base))
  if (!length(cols)) return(tibble())
  base %>%
    filter(en_muestra) %>%
    select(liga, casa, momento, all_of(cols)) %>%
    pivot_longer(all_of(cols), names_to = "metodo", values_to = "parametro",
                 names_prefix = "param_") %>%
    group_by(liga, casa, momento, metodo) %>%
    summarise(media = mean(parametro), mediana = median(parametro),
              p05 = quantile(parametro, 0.05), p95 = quantile(parametro, 0.95),
              .groups = "drop") %>%
    redondear(4)
}

graficar_sensibilidad_metodos <- function(pred, cfg) {
  principal <- cfg$normalizacion$metodo_principal
  ref <- pred %>% filter(metodo == principal, momento == "apertura") %>%
    select(partido_id, casa, desenlace, p_ref = p)
  d <- pred %>%
    filter(metodo != principal, momento == "apertura") %>%
    inner_join(ref, by = c("partido_id", "casa", "desenlace")) %>%
    mutate(dif_pp = 100 * (p - p_ref))

  g <- ggplot(d, aes(x = p_ref, y = dif_pp, color = metodo)) +
    geom_hline(yintercept = 0, color = "grey50") +
    geom_point(alpha = 0.15, size = 0.6) +
    facet_wrap(~ casa) +
    labs(title = sprintf("Diferencia entre métodos de remoción del margen (frente al %s)", principal),
         subtitle = paste(subtitulo_alcance(cfg), "· cuotas de apertura"),
         x = sprintf("Probabilidad con el método %s", principal),
         y = "Diferencia (puntos porcentuales)", color = "Método") +
    guides(color = guide_legend(override.aes = list(alpha = 1, size = 2))) +
    tema_proyecto()
  ggsave(file.path(cfg$rutas$figuras, "fig4_sensibilidad_metodos.png"), g,
         width = 9, height = 5, dpi = 150, bg = "white")
  invisible(g)
}
