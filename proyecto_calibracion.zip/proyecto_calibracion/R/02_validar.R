# =============================================================================
# 02_validar.R · Validaciones de la base consolidada
# Cada chequeo queda como una fila: liga, temporada, chequeo, valor, estado.
#   OK      = sin problemas
#   REVISAR = hay algo que investigar antes de seguir
#   INFO    = dato informativo (se trata en el inventario de cobertura)
# =============================================================================

validar_datos <- function(partidos, registro, cfg) {
  ligas <- tabla_ligas(cfg)
  casas <- tabla_casas(cfg)
  cols  <- columnas_cuotas(casas$prefijo, unlist(cfg$momentos))

  por_temporada <- partidos %>%
    mutate(resultado_calculado = case_when(
      goles_local > goles_visitante ~ "H",
      goles_local < goles_visitante ~ "A",
      goles_local == goles_visitante ~ "D"
    )) %>%
    group_by(liga, temporada) %>%
    summarise(
      partidos_leidos         = n(),
      div_distinto_al_esperado = sum(div_archivo != codigo_esperado | is.na(div_archivo)),
      fechas_no_interpretables = sum(is.na(fecha)),
      fechas_fuera_de_temporada = sum(
        fecha < make_date(anio_inicio, 7, 1) | fecha > make_date(anio_inicio + 1, 8, 31),
        na.rm = TRUE),
      resultado_faltante      = sum(is.na(resultado) | is.na(resultado_calculado)),
      resultado_inconsistente = sum(resultado != resultado_calculado, na.rm = TRUE),
      partidos_duplicados     = sum(duplicated(paste(local, visitante))),
      cuotas_menores_o_iguales_a_1 = sum(as.matrix(pick(all_of(cols))) <= 1, na.rm = TRUE),
      cuotas_faltantes        = sum(is.na(as.matrix(pick(all_of(cols))))),
      .groups = "drop"
    ) %>%
    left_join(select(ligas, liga, partidos_esperados), by = "liga") %>%
    mutate(diferencia_vs_partidos_esperados = partidos_leidos - partidos_esperados) %>%
    select(-partidos_esperados) %>%
    left_join(
      registro %>% group_by(liga, temporada) %>%
        summarise(cuotas_no_numericas = sum(cuotas_no_numericas), .groups = "drop"),
      by = c("liga", "temporada")
    )

  # Cuotas posteriores a la fecha de corte declarada por la fuente (Pinnacle)
  corte <- casas %>% filter(!is.na(fecha_corte))
  if (nrow(corte) > 0) {
    for (i in seq_len(nrow(corte))) {
      cols_casa <- columnas_cuotas(corte$prefijo[i], unlist(cfg$momentos))
      nombre <- paste0("cuotas_posteriores_a_corte_", corte$casa[i])
      conteo <- partidos %>%
        mutate(tiene = rowSums(!is.na(as.matrix(pick(all_of(cols_casa))))) > 0,
               posterior = !is.na(fecha) & fecha >= corte$fecha_corte[i]) %>%
        group_by(liga, temporada) %>%
        summarise(!!nombre := sum(tiene & posterior), .groups = "drop")
      por_temporada <- left_join(por_temporada, conteo, by = c("liga", "temporada"))
    }
  }

  por_temporada %>%
    pivot_longer(-c(liga, temporada), names_to = "chequeo", values_to = "valor") %>%
    mutate(estado = case_when(
      chequeo == "partidos_leidos"  ~ "INFO",
      chequeo == "cuotas_faltantes" ~ if_else(valor == 0, "OK", "INFO"),
      grepl("^cuotas_posteriores_a_corte", chequeo) ~ if_else(valor == 0, "OK", "SE EXCLUYEN"),
      valor == 0 ~ "OK",
      TRUE ~ "REVISAR"
    )) %>%
    arrange(liga, temporada, chequeo)
}

imprimir_validacion <- function(validaciones) {
  revisar <- filter(validaciones, estado == "REVISAR")
  if (nrow(revisar) == 0) {
    message("   Todas las validaciones críticas en OK")
  } else {
    message("   ATENCIÓN: ", nrow(revisar), " chequeos para REVISAR:")
    print(revisar, n = Inf)
  }
  info <- filter(validaciones, estado %in% c("INFO", "SE EXCLUYEN"), chequeo != "partidos_leidos")
  if (nrow(info) > 0) {
    message("   Para el inventario de cobertura:")
    print(info, n = Inf)
  }
}
