# =============================================================================
# 04_margen.R · Probabilidades implícitas brutas y margen del operador
#
# p_bruta = 1 / cuota. En un mercado 1X2 las tres suman más de 1; el exceso es
# el margen (overround). AQUÍ NO SE COMPARA NADA CONTRA FRECUENCIAS
# OBSERVADAS: las probabilidades brutas están infladas por construcción. Las
# probabilidades normalizadas se agregan en la Fase 2.
# =============================================================================

calcular_base_analitica <- function(largo) {
  largo %>%
    mutate(
      pbruta_H    = 1 / cuota_H,
      pbruta_D    = 1 / cuota_D,
      pbruta_A    = 1 / cuota_A,
      suma_pbruta = pbruta_H + pbruta_D + pbruta_A,
      margen_pp   = (suma_pbruta - 1) * 100,
      # Retorno teórico por cada 100 apostados si el margen se reparte de
      # forma proporcional entre los tres resultados: 100 / (1 + margen)
      retorno_teorico_por_100 = 100 / suma_pbruta,
      across(c(pbruta_H, pbruta_D, pbruta_A, suma_pbruta, margen_pp,
               retorno_teorico_por_100),
             ~ if_else(mercado_valido, .x, NA_real_))
    )
}

resumir_margen <- function(base, ...) {
  base %>%
    filter(en_muestra) %>%
    group_by(...) %>%
    summarise(
      n_partidos = n(),
      media      = mean(margen_pp),
      mediana    = median(margen_pp),
      de         = sd(margen_pp),
      p05        = quantile(margen_pp, 0.05),
      p25        = quantile(margen_pp, 0.25),
      p75        = quantile(margen_pp, 0.75),
      p95        = quantile(margen_pp, 0.95),
      retorno_teorico_por_100 = mean(retorno_teorico_por_100),
      perdida_esperada_por_100 = 100 - mean(retorno_teorico_por_100),
      .groups = "drop"
    ) %>%
    redondear(3)
}

# --- Comparaciones -----------------------------------------------------------
# Apareadas (mismos partidos): diferencia por partido, IC y valor p por
# bootstrap de bloques (fecha), que respeta la dependencia entre partidos del
# mismo día. La prueba de rangos con signo de Wilcoxon (que supone partidos
# independientes) se reporta como complemento.
resumen_apareado <- function(dif, bloque, B, nivel, ...) {
  bs <- boot_media_bloques(dif, bloque, B)
  a  <- (1 - nivel) / 2
  tibble(
    ...,
    n_partidos   = length(dif),
    dif_media_pp = mean(dif),
    dif_mediana_pp = median(dif),
    ic_inf_pp    = unname(quantile(bs, a)),
    ic_sup_pp    = unname(quantile(bs, 1 - a)),
    p_bootstrap  = p_bootstrap(bs, mean(dif)),
    p_wilcoxon   = wilcox.test(dif, mu = 0, exact = FALSE)$p.value
  )
}

# Independientes (partidos distintos, p. ej. dos ligas): bootstrap de bloques
# dentro de cada grupo por separado; Wilcoxon de suma de rangos como complemento.
resumen_independiente <- function(x1, b1, x2, b2, B, nivel, ...) {
  bs <- boot_media_bloques(x2, b2, B) - boot_media_bloques(x1, b1, B)
  a  <- (1 - nivel) / 2
  tibble(
    ...,
    n_partidos   = length(x1) + length(x2),
    dif_media_pp = mean(x2) - mean(x1),
    dif_mediana_pp = median(x2) - median(x1),
    ic_inf_pp    = unname(quantile(bs, a)),
    ic_sup_pp    = unname(quantile(bs, 1 - a)),
    p_bootstrap  = p_bootstrap(bs, mean(x2) - mean(x1)),
    p_wilcoxon   = wilcox.test(x2, x1, exact = FALSE)$p.value
  )
}

comparaciones_margen <- function(base, cfg) {
  B     <- cfg$inferencia$n_bootstrap
  nivel <- cfg$inferencia$nivel_confianza
  casas    <- tabla_casas(cfg)$casa
  ligas    <- tabla_ligas(cfg)$liga
  momentos <- unlist(cfg$momentos)

  m <- base %>%
    filter(en_muestra) %>%
    select(partido_id, liga, fecha, casa, momento, margen_pp)

  resultados <- list()

  # (a) Entre casas, dentro de cada liga y momento (apareado)
  if (length(casas) == 2) {
    for (lg in ligas) for (mo in momentos) {
      w <- m %>% filter(liga == lg, momento == mo) %>%
        pivot_wider(names_from = casa, values_from = margen_pp)
      resultados[[length(resultados) + 1]] <- resumen_apareado(
        w[[casas[1]]] - w[[casas[2]]], w$fecha, B, nivel,
        familia = "Entre casas", liga = lg, casa = "-", momento = mo,
        contraste = paste(casas[1], "menos", casas[2]))
    }
  }

  # (b) Apertura vs cierre, dentro de cada liga y casa (apareado)
  if (all(c("apertura", "cierre") %in% momentos)) {
    for (lg in ligas) for (cs in casas) {
      w <- m %>% filter(liga == lg, casa == cs) %>%
        pivot_wider(names_from = momento, values_from = margen_pp)
      resultados[[length(resultados) + 1]] <- resumen_apareado(
        w$apertura - w$cierre, w$fecha, B, nivel,
        familia = "Apertura vs cierre", liga = lg, casa = cs, momento = "-",
        contraste = "apertura menos cierre")
    }
  }

  # (c) Entre ligas, dentro de cada casa y momento (independiente)
  if (length(ligas) == 2) {
    for (cs in casas) for (mo in momentos) {
      g1 <- m %>% filter(liga == ligas[1], casa == cs, momento == mo)
      g2 <- m %>% filter(liga == ligas[2], casa == cs, momento == mo)
      resultados[[length(resultados) + 1]] <- resumen_independiente(
        g1$margen_pp, g1$fecha, g2$margen_pp, g2$fecha, B, nivel,
        familia = "Entre ligas", liga = "-", casa = cs, momento = mo,
        contraste = paste(ligas[2], "menos", ligas[1]))
    }
  }

  # Control de comparaciones múltiples: Holm sobre toda la familia de
  # contrastes principales, definida de antemano en este script.
  # Los valores p no se redondean (saldrían como 0); se agrega una versión en
  # texto con el formato "< 0.001" para tablas e informe.
  bind_rows(resultados) %>%
    mutate(p_holm = p.adjust(p_bootstrap, method = "holm"),
           p_holm_texto = format.pval(p_holm, digits = 2, eps = 0.001)) %>%
    mutate(across(c(n_partidos, dif_media_pp, dif_mediana_pp, ic_inf_pp, ic_sup_pp),
                  ~ round(.x, 3)))
}

# Diferencia entre ligas temporada por temporada. Es DESCRIPTIVA (solo IC, sin
# valores p) para no multiplicar contrastes; sirve para verificar si la
# diferencia global es estable o la produce una sola temporada.
comparar_ligas_por_temporada <- function(base, cfg) {
  B     <- cfg$inferencia$n_bootstrap
  nivel <- cfg$inferencia$nivel_confianza
  ligas <- tabla_ligas(cfg)$liga
  if (length(ligas) != 2) return(tibble())
  a <- (1 - nivel) / 2

  base %>%
    filter(en_muestra) %>%
    group_by(temporada, casa, momento) %>%
    group_modify(function(d, k) {
      g1 <- filter(d, liga == ligas[1]); g2 <- filter(d, liga == ligas[2])
      bs <- boot_media_bloques(g2$margen_pp, g2$fecha, B) -
            boot_media_bloques(g1$margen_pp, g1$fecha, B)
      tibble(contraste = paste(ligas[2], "menos", ligas[1]),
             dif_media_pp = mean(g2$margen_pp) - mean(g1$margen_pp),
             ic_inf_pp = unname(quantile(bs, a)),
             ic_sup_pp = unname(quantile(bs, 1 - a)))
    }) %>%
    ungroup() %>%
    redondear(3)
}

# --- Figuras -----------------------------------------------------------------
# Las figuras se adaptan al alcance: con una sola liga, los colores distinguen
# casas; con dos ligas, distinguen ligas.
graficar_margen <- function(base, resumen_temp, comparaciones, cfg) {
  dir_fig <- cfg$rutas$figuras
  temps <- unlist(cfg$temporadas)
  ligas <- tabla_ligas(cfg)$liga
  una_liga <- length(ligas) == 1
  subt <- sprintf("%s · temporadas %s a %s · muestra apareada",
                  paste(ligas, collapse = " y "),
                  etiqueta_temporada(min(temps)), etiqueta_temporada(max(temps)))
  tema <- theme_minimal(base_size = 11) +
    theme(legend.position = "bottom", panel.grid.minor = element_blank())

  d <- filter(base, en_muestra)

  # Figura 1: distribución del margen por partido
  g1 <- ggplot(d, aes(x = casa, y = margen_pp, fill = if (una_liga) casa else liga)) +
    geom_boxplot(outlier.size = 0.4, outlier.alpha = 0.4, width = 0.6) +
    facet_wrap(~ momento) +
    labs(title = "Distribución del margen del operador por partido",
         subtitle = subt, x = NULL, y = "Margen (puntos porcentuales)", fill = NULL) +
    tema
  if (una_liga) g1 <- g1 + theme(legend.position = "none")
  ggsave(file.path(dir_fig, "fig1_margen_distribucion.png"), g1,
         width = 9, height = 5, dpi = 150, bg = "white")

  # Figura 2: margen mediano por temporada
  grupo <- if (una_liga) "casa" else "liga"
  g2 <- ggplot(resumen_temp, aes(x = temporada, y = mediana,
                                 color = .data[[grupo]], group = .data[[grupo]])) +
    geom_ribbon(aes(ymin = p25, ymax = p75, fill = .data[[grupo]]), alpha = 0.15, color = NA) +
    geom_line() + geom_point() +
    labs(title = "Margen mediano por temporada (banda: rango intercuartílico)",
         subtitle = subt, x = NULL, y = "Margen (puntos porcentuales)",
         color = NULL, fill = NULL) +
    tema + theme(axis.text.x = element_text(angle = 45, hjust = 1))
  g2 <- if (una_liga) g2 + facet_wrap(~ momento) else g2 + facet_grid(casa ~ momento)
  ggsave(file.path(dir_fig, "fig2_margen_por_temporada.png"), g2,
         width = 9, height = if (una_liga) 5 else 6, dpi = 150, bg = "white")

  # Figura 3: diferencias con IC 95 %
  cmp <- comparaciones %>%
    mutate(etiqueta = paste0(contraste, " · ",
                             if_else(liga == "-" | una_liga, "", paste0(liga, " ")),
                             if_else(casa == "-", "", paste0(casa, " ")),
                             if_else(momento == "-", "", momento)))
  g3 <- ggplot(cmp, aes(x = dif_media_pp, y = reorder(etiqueta, dif_media_pp))) +
    geom_vline(xintercept = 0, linetype = 2, color = "grey50") +
    geom_errorbar(aes(xmin = ic_inf_pp, xmax = ic_sup_pp), width = 0.25, orientation = "y") +
    geom_point(size = 2) +
    facet_wrap(~ familia, ncol = 1, scales = "free_y") +
    labs(title = "Diferencias de margen medio con IC 95 % (bootstrap por fecha)",
         subtitle = subt, x = "Diferencia (puntos porcentuales)", y = NULL) +
    tema
  ggsave(file.path(dir_fig, "fig3_comparaciones_margen.png"), g3,
         width = 9, height = if (una_liga) 4.5 else 7, dpi = 150, bg = "white")

  invisible(list(g1, g2, g3))
}
