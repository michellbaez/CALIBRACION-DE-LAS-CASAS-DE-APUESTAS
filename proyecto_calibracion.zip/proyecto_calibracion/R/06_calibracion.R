# =============================================================================
# 06_calibracion.R · Fase 3: evaluación de la calibración
#
# Decisión sobre los tres resultados: en el análisis principal se AGRUPAN las
# tres predicciones de cada partido (local, empate, visitante) en una sola
# curva. Así se cubre todo el rango de probabilidad y cada intervalo tiene
# más datos. Como verificación, se repite la curva para cada resultado por
# separado (figura 8). La dependencia entre las tres predicciones de un mismo
# partido se respeta en la inferencia porque el bootstrap remuestrea partidos
# completos (agrupados por fecha).
# =============================================================================

# Intervalos de probabilidad.
#   igual_frecuencia: k grupos con el mismo número de predicciones.
#   igual_ancho:      k intervalos de 1/k de ancho (0-0.1, 0.1-0.2, ...).
asignar_intervalos <- function(p, esquema, k) {
  switch(esquema,
         igual_frecuencia = ntile(p, k),
         igual_ancho = as.integer(cut(p, breaks = seq(0, 1, length.out = k + 1),
                                      include.lowest = TRUE)),
         stop("Esquema desconocido: ", esquema))
}

grupos_base <- c("liga", "casa", "momento", "metodo")

# Curva de calibración: por intervalo, probabilidad media predicha frente a
# frecuencia observada, con intervalo de Wilson y desviación en pp.
curva_calibracion <- function(pred, esquema, k, nivel = 0.95, grupos = grupos_base) {
  pred %>%
    group_by(across(all_of(grupos))) %>%
    mutate(intervalo = asignar_intervalos(p, esquema, k)) %>%
    group_by(across(all_of(c(grupos, "intervalo")))) %>%
    summarise(n = n(), p_media = mean(p), exitos = sum(y),
              p_min = min(p), p_max = max(p), .groups = "drop") %>%
    mutate(esquema = esquema, k = k,
           frec_obs = exitos / n,
           ic_inf = wilson_ic(exitos, n, nivel)$inf,
           ic_sup = wilson_ic(exitos, n, nivel)$sup,
           desviacion_pp = 100 * (frec_obs - p_media),
           desv_ic_inf_pp = 100 * (ic_inf - p_media),
           desv_ic_sup_pp = 100 * (ic_sup - p_media),
           diagonal_dentro_ic = p_media >= ic_inf & p_media <= ic_sup)
}

# Todas las combinaciones de esquema y número de intervalos que se reportan
curvas_todas <- function(pred, cfg) {
  combinaciones <- bind_rows(
    tibble(esquema = "igual_frecuencia", k = unlist(cfg$calibracion$n_intervalos_sensibilidad)),
    tibble(esquema = "igual_ancho", k = cfg$calibracion$n_intervalos)
  ) %>% distinct()
  pmap_dfr(combinaciones, function(esquema, k) {
    curva_calibracion(pred, esquema, k, cfg$inferencia$nivel_confianza)
  })
}

# Resumen de magnitud por curva:
#   ece_pp     desviación absoluta media, ponderada por el tamaño del intervalo
#   max_abs_pp la mayor desviación absoluta de un intervalo
resumir_curvas <- function(curvas, grupos = grupos_base) {
  curvas %>%
    group_by(across(all_of(c(grupos, "esquema", "k")))) %>%
    summarise(n_predicciones = sum(n),
              ece_pp = sum(n * abs(desviacion_pp)) / sum(n),
              max_abs_pp = max(abs(desviacion_pp)),
              intervalos_fuera_ic = sum(!diagonal_dentro_ic),
              .groups = "drop") %>%
    redondear(3)
}

# ¿Cuánto error de calibración aparecería SOLO por azar si las probabilidades
# fueran perfectas? Se simulan resultados con las propias probabilidades de
# la casa (un desenlace por partido, respetando que los tres suman 1) y se
# recalcula el ECE con los mismos intervalos. Si el ECE observado está dentro
# de lo que da el azar, la desviación no se distingue del ruido.
ece_esperado_por_azar <- function(pred, cfg) {
  esquema <- cfg$calibracion$esquema_principal
  k <- cfg$calibracion$n_intervalos
  R <- cfg$calibracion$n_simulaciones

  pred %>%
    arrange(partido_id, desenlace) %>%            # filas en tríos A, D, H
    group_by(across(all_of(grupos_base))) %>%
    group_modify(function(d, clave) {
      intervalo <- asignar_intervalos(d$p, esquema, k)
      ece <- function(y) sum(abs(rowsum(y - d$p, intervalo))) / nrow(d) * 100
      P <- matrix(d$p, ncol = 3, byrow = TRUE)   # columnas A, D, H
      acum <- t(apply(P, 1, cumsum))
      N <- nrow(P)
      sim <- replicate(R, {
        u <- runif(N)
        cual <- 1 + (u > acum[, 1]) + (u > acum[, 2])
        Y <- matrix(0L, N, 3); Y[cbind(seq_len(N), cual)] <- 1L
        ece(as.vector(t(Y)))
      })
      observado <- ece(d$y)
      tibble(ece_observado_pp = observado,
             ece_azar_media_pp = mean(sim),
             ece_azar_p95_pp = unname(quantile(sim, 0.95)),
             p_simulacion = mean(sim >= observado))
    }) %>%
    ungroup() %>%
    redondear(3)
}

# --- Reglas de puntuación -------------------------------------------------------
# Brier (multiclase): suma de (p - y)^2 en los tres desenlaces. 0 = perfecto.
# RPS: respeta el orden local > empate > visitante; castiga menos equivocarse
# por un "paso" (predecir empate cuando gana el local) que por dos.
metricas_partido <- function(pred) {
  pred %>%
    select(partido_id, liga, temporada, anio_inicio, fecha, casa, momento,
           metodo, desenlace, p, y) %>%
    pivot_wider(names_from = desenlace, values_from = c(p, y)) %>%
    mutate(brier = (p_H - y_H)^2 + (p_D - y_D)^2 + (p_A - y_A)^2,
           rps   = 0.5 * ((p_H - y_H)^2 + (p_H + p_D - y_H - y_D)^2))
}

puntuar <- function(pH, pD, pA, yH, yD, yA) {
  list(brier = (pH - yH)^2 + (pD - yD)^2 + (pA - yA)^2,
       rps   = 0.5 * ((pH - yH)^2 + (pH + pD - yH - yD)^2))
}

# Líneas base: (1) uniforme, 1/3 para cada desenlace; (2) frecuencia
# histórica, la proporción de locales, empates y visitantes de la muestra.
# La (2) usa los mismos datos que evalúa, lo que la favorece: es una
# referencia exigente (conservadora) para las casas.
puntuaciones <- function(metricas, cfg) {
  B <- cfg$inferencia$n_bootstrap
  a <- (1 - cfg$inferencia$nivel_confianza) / 2

  map_dfr(unique(metricas$liga), function(lg) {
    m <- filter(metricas, liga == lg)
    partidos <- distinct(m, partido_id, fecha, y_H, y_D, y_A)
    frec <- colMeans(partidos[, c("y_H", "y_D", "y_A")])
    uni  <- puntuar(1/3, 1/3, 1/3, partidos$y_H, partidos$y_D, partidos$y_A)
    his  <- puntuar(frec[1], frec[2], frec[3], partidos$y_H, partidos$y_D, partidos$y_A)

    bloques <- as.integer(factor(m$fecha))
    W <- generar_pesos_bootstrap(max(bloques), B)

    m %>%
      mutate(bloque = bloques) %>%
      group_by(liga, casa, momento, metodo) %>%
      group_modify(function(d, clave) {
        bs_brier <- media_bootstrap(d$brier, d$bloque, W)
        bs_rps   <- media_bootstrap(d$rps, d$bloque, W)
        tibble(n_partidos = nrow(d),
               brier = mean(d$brier),
               brier_ic_inf = unname(quantile(bs_brier, a)),
               brier_ic_sup = unname(quantile(bs_brier, 1 - a)),
               rps = mean(d$rps),
               rps_ic_inf = unname(quantile(bs_rps, a)),
               rps_ic_sup = unname(quantile(bs_rps, 1 - a)))
      }) %>%
      ungroup() %>%
      mutate(brier_uniforme = mean(uni$brier), rps_uniforme = mean(uni$rps),
             brier_historica = mean(his$brier), rps_historica = mean(his$rps),
             frec_local = frec[1], frec_empate = frec[2], frec_visitante = frec[3],
             mejora_brier_vs_uniforme_pct  = 100 * (1 - brier / brier_uniforme),
             mejora_brier_vs_historica_pct = 100 * (1 - brier / brier_historica),
             mejora_rps_vs_historica_pct   = 100 * (1 - rps / rps_historica))
  }) %>%
    redondear(4)
}

# --- Descomposición de Murphy --------------------------------------------------
# Para cada desenlace (problema binario), con intervalos de igual frecuencia:
#   Brier = fiabilidad - resolución + incertidumbre (+ término por agrupar)
#   fiabilidad:   cuánto se alejan las probabilidades de las frecuencias
#                 (es el error de CALIBRACIÓN; menor es mejor)
#   resolución:   cuánto separa el pronóstico situaciones distintas de la
#                 frecuencia media (mayor es mejor)
#   incertidumbre: dificultad propia del fenómeno, no depende de la casa
# El Brier multiclase es la suma de los tres Brier binarios, así que las
# componentes también se suman.
murphy <- function(pred, cfg) {
  k <- cfg$calibracion$n_intervalos
  por_desenlace <- pred %>%
    group_by(across(all_of(c(grupos_base, "desenlace")))) %>%
    mutate(intervalo = ntile(p, k), obar = mean(y), N = n(),
           brier_bin = mean((p - y)^2)) %>%
    group_by(across(all_of(c(grupos_base, "desenlace", "intervalo")))) %>%
    summarise(n = n(), p_med = mean(p), o_med = mean(y),
              obar = first(obar), N = first(N), brier_bin = first(brier_bin),
              .groups = "drop") %>%
    group_by(across(all_of(c(grupos_base, "desenlace")))) %>%
    summarise(brier = first(brier_bin),
              fiabilidad = sum(n * (p_med - o_med)^2) / first(N),
              resolucion = sum(n * (o_med - first(obar))^2) / first(N),
              incertidumbre = first(obar) * (1 - first(obar)),
              # Fiabilidad que aparecería solo por azar aunque la casa
              # estuviera perfectamente calibrada (aproximación: suma de las
              # varianzas binomiales de cada intervalo dividida por N)
              fiabilidad_esperada_azar = sum(p_med * (1 - p_med)) / first(N),
              .groups = "drop") %>%
    mutate(termino_agrupamiento = brier - (fiabilidad - resolucion + incertidumbre))

  total <- por_desenlace %>%
    group_by(across(all_of(grupos_base))) %>%
    summarise(across(c(brier, fiabilidad, resolucion, incertidumbre,
                       termino_agrupamiento, fiabilidad_esperada_azar), sum),
              .groups = "drop") %>%
    mutate(desenlace = "Total")

  bind_rows(por_desenlace, total) %>%
    mutate(desenlace = recode(desenlace, !!!nombre_desenlace)) %>%
    arrange(across(all_of(grupos_base)), desenlace) %>%
    redondear(5)
}

# --- Hosmer-Lemeshow -----------------------------------------------------------
# Por desenlace (la prueba es para resultados binarios), con g grupos de igual
# frecuencia. Grados de libertad = g: las probabilidades NO se estimaron con
# estos datos (validación externa). La versión g - 2 de algunos paquetes es
# para modelos ajustados sobre la misma muestra.
# Se reporta junto a la magnitud (desviación absoluta media en pp) porque con
# miles de partidos la prueba detecta desviaciones mínimas.
hosmer_lemeshow <- function(pred, cfg) {
  map_dfr(unlist(cfg$calibracion$grupos_hosmer_lemeshow), function(g) {
    pred %>%
      group_by(across(all_of(c(grupos_base, "desenlace")))) %>%
      mutate(grupo = ntile(p, g)) %>%
      group_by(across(all_of(c(grupos_base, "desenlace", "grupo")))) %>%
      summarise(n = n(), O = sum(y), E = sum(p), .groups = "drop_last") %>%
      summarise(estadistico = sum((O - E)^2 / (E * (1 - E / n))),
                desv_abs_media_pp = 100 * sum(abs(O - E)) / sum(n),
                .groups = "drop") %>%
      mutate(grupos = g, gl = g,
             p_valor = pchisq(estadistico, df = gl, lower.tail = FALSE))
  }) %>%
    mutate(desenlace = recode(desenlace, !!!nombre_desenlace),
           p_texto = formato_p(p_valor)) %>%
    redondear(4)
}

# Calibración "en el grueso" por desenlace: probabilidad media predicha frente
# a frecuencia observada, sin agrupar por intervalos.
grueso_por_desenlace <- function(pred, cfg, grupos = grupos_base) {
  nivel <- cfg$inferencia$nivel_confianza
  pred %>%
    group_by(across(all_of(c(grupos, "desenlace")))) %>%
    summarise(n = n(), p_media = mean(p), exitos = sum(y), .groups = "drop") %>%
    mutate(frec_obs = exitos / n,
           ic_inf = wilson_ic(exitos, n, nivel)$inf,
           ic_sup = wilson_ic(exitos, n, nivel)$sup,
           desviacion_pp = 100 * (frec_obs - p_media),
           desenlace = recode(desenlace, !!!nombre_desenlace)) %>%
    redondear(4)
}

# --- Figuras de la Fase 3 --------------------------------------------------------
graficar_calibracion <- function(curvas, curvas_desenlace, cfg) {
  dir_fig <- cfg$rutas$figuras
  principal <- cfg$normalizacion$metodo_principal
  esquema <- cfg$calibracion$esquema_principal
  k <- cfg$calibracion$n_intervalos
  subt <- sprintf("%s\nmétodo %s · %d intervalos de %s · IC de Wilson 95 %%",
                  subtitulo_alcance(cfg), principal, k, gsub("_", " ", esquema))
  # Pequeño desplazamiento horizontal entre casas para que no se tapen
  desplazar <- function(d, ancho = 0.008) {
    i <- as.integer(factor(d$casa))
    mutate(d, x_graf = p_media + (i - mean(unique(i))) * ancho)
  }

  c_princ <- curvas %>% filter(metodo == principal, esquema == !!esquema, k == !!k) %>% desplazar()

  # Figura 5: curvas de calibración
  g5 <- ggplot(c_princ, aes(x = x_graf, y = frec_obs, color = casa)) +
    geom_abline(slope = 1, intercept = 0, linetype = 2, color = "grey50") +
    geom_errorbar(aes(ymin = ic_inf, ymax = ic_sup), width = 0) +
    geom_point(size = 1.8) +
    geom_line(alpha = 0.5) +
    facet_wrap(~ momento) +
    coord_equal(xlim = c(0, 1), ylim = c(0, 1)) +
    labs(title = "Curvas de calibración: probabilidad implícita frente a frecuencia observada",
         subtitle = subt, x = "Probabilidad implícita media del intervalo",
         y = "Frecuencia observada", color = NULL) +
    tema_proyecto()
  ggsave(file.path(dir_fig, "fig5_curvas_calibracion.png"), g5,
         width = 9, height = 5.5, dpi = 150, bg = "white")

  # Figura 6: desviación por intervalo (la misma curva, ampliada)
  g6 <- ggplot(c_princ, aes(x = x_graf, y = desviacion_pp, color = casa)) +
    geom_hline(yintercept = 0, linetype = 2, color = "grey50") +
    geom_errorbar(aes(ymin = desv_ic_inf_pp, ymax = desv_ic_sup_pp), width = 0) +
    geom_point(size = 1.8) +
    facet_wrap(~ momento) +
    labs(title = "Desviación por intervalo: frecuencia observada menos probabilidad implícita",
         subtitle = subt, x = "Probabilidad implícita media del intervalo",
         y = "Desviación (puntos porcentuales)", color = NULL) +
    tema_proyecto()
  ggsave(file.path(dir_fig, "fig6_desviaciones_por_intervalo.png"), g6,
         width = 9, height = 5, dpi = 150, bg = "white")

  # Figura 7: sensibilidad al esquema y número de intervalos (apertura)
  c_sens <- curvas %>%
    filter(metodo == principal, momento == "apertura") %>%
    mutate(esquema_k = factor(paste0(gsub("_", " ", esquema), ", ", k, " intervalos"))) %>%
    desplazar()
  g7 <- ggplot(c_sens, aes(x = x_graf, y = desviacion_pp, color = casa)) +
    geom_hline(yintercept = 0, linetype = 2, color = "grey50") +
    geom_errorbar(aes(ymin = desv_ic_inf_pp, ymax = desv_ic_sup_pp), width = 0, alpha = 0.6) +
    geom_point(size = 1.4) +
    facet_wrap(~ esquema_k) +
    coord_cartesian(ylim = c(-15, 15)) +
    labs(title = "Sensibilidad de la curva al esquema de agrupamiento (cuotas de apertura)",
         subtitle = paste(subtitulo_alcance(cfg), "· método", principal),
         x = "Probabilidad implícita media del intervalo",
         y = "Desviación (puntos porcentuales)", color = NULL) +
    tema_proyecto()
  ggsave(file.path(dir_fig, "fig7_sensibilidad_agrupamiento.png"), g7,
         width = 9, height = 6.5, dpi = 150, bg = "white")

  # Figura 8: cada desenlace por separado (apertura)
  c_des <- curvas_desenlace %>%
    filter(metodo == principal, momento == "apertura") %>%
    mutate(desenlace = factor(recode(desenlace, !!!nombre_desenlace),
                              levels = nombre_desenlace)) %>%
    desplazar(ancho = 0.004)
  g8 <- ggplot(c_des, aes(x = x_graf, y = desviacion_pp, color = casa)) +
    geom_hline(yintercept = 0, linetype = 2, color = "grey50") +
    geom_errorbar(aes(ymin = desv_ic_inf_pp, ymax = desv_ic_sup_pp), width = 0) +
    geom_point(size = 1.6) +
    facet_wrap(~ desenlace, scales = "free_x") +
    labs(title = "Desviación por intervalo para cada desenlace por separado (cuotas de apertura)",
         subtitle = paste0(subtitulo_alcance(cfg), "\nmétodo ", principal, " · ", k, " intervalos de igual frecuencia por desenlace"),
         x = "Probabilidad implícita media del intervalo",
         y = "Desviación (puntos porcentuales)", color = NULL) +
    tema_proyecto()
  ggsave(file.path(dir_fig, "fig8_calibracion_por_desenlace.png"), g8,
         width = 10, height = 4.8, dpi = 150, bg = "white")

  invisible(list(g5, g6, g7, g8))
}
