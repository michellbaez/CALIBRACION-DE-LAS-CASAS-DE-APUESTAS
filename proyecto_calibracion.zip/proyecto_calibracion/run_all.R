# =============================================================================
# run_all.R · Script maestro
# Regenera TODO el flujo con un solo comando, en cualquier computador:
#     Rscript run_all.R                      (Terminal, desde la carpeta del proyecto)
#     Rscript "C:/ruta/al/proyecto/run_all.R"  (Terminal, desde cualquier carpeta)
#     source("run_all.R")                    (Consola de RStudio)
# Para agregar una temporada o cambiar de liga solo se edita config.yml.
# =============================================================================

# --- 0. Ubicación del proyecto ------------------------------------------------
# El script encuentra solo la carpeta del proyecto (la que contiene config.yml).
# Si en algún computador no la encuentra, hay dos formas de indicarla a mano:
#   1. Escribir la ruta completa aquí abajo, con barras "/" (no "\"):
RUTA_PROYECTO <- ""   # ejemplo: "C:/Users/Ana/Documents/proyecto_calibracion"
#   2. O definir la variable de entorno PROYECTO_CALIBRACION con esa ruta.
# Las rutas de datos y resultados se configuran en config.yml (bloque rutas).

localizar_proyecto <- function(ruta_manual = "") {
  desde_rscript <- function() {          # Rscript run_all.R
    arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
    # Rscript escribe los espacios de la ruta como "~+~": se devuelven a espacios
    if (length(arg)) dirname(gsub("~+~", " ", sub("^--file=", "", arg[1]), fixed = TRUE)) else ""
  }
  desde_source <- function() {           # source("ruta/run_all.R")
    for (i in rev(seq_len(sys.nframe()))) {
      of <- sys.frame(i)$ofile
      if (!is.null(of)) return(dirname(of))
    }
    ""
  }
  desde_rstudio <- function() {          # líneas ejecutadas en el editor de RStudio
    if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
      ruta <- tryCatch(rstudioapi::getSourceEditorContext()$path, error = function(e) "")
      if (nzchar(ruta)) return(dirname(ruta))
    }
    ""
  }
  candidatos <- c(ruta_manual, Sys.getenv("PROYECTO_CALIBRACION"), desde_rscript(),
                  desde_source(), desde_rstudio(), getwd())
  for (cand in candidatos) {
    if (nzchar(cand) && file.exists(file.path(cand, "config.yml"))) {
      return(normalizePath(cand, winslash = "/"))
    }
  }
  stop("No se encontró la carpeta del proyecto (la que contiene config.yml).\n",
       "Escriba su ruta en RUTA_PROYECTO, al inicio de run_all.R.", call. = FALSE)
}

setwd(localizar_proyecto(RUTA_PROYECTO))
message("Proyecto: ", getwd())

# --- Paquetes: se instalan solos los que falten ---------------------------------
paquetes <- c("dplyr", "tidyr", "readr", "purrr", "lubridate", "ggplot2", "yaml", "rmarkdown")
faltan <- paquetes[!vapply(paquetes, requireNamespace, logical(1), quietly = TRUE)]
if (length(faltan)) {
  message("Instalando paquetes faltantes: ", paste(faltan, collapse = ", "))
  install.packages(faltan, repos = "https://cloud.r-project.org")
}

for (f in sort(list.files("R", pattern = "\\.R$", full.names = TRUE))) {
  source(f, encoding = "UTF-8")
}

cfg <- read_yaml("config.yml")
set.seed(cfg$inferencia$semilla)
for (ruta in cfg$rutas) dir.create(ruta, recursive = TRUE, showWarnings = FALSE)
guardar <- function(df, nombre, carpeta = cfg$rutas$tablas) {
  if (nrow(df) > 0) write_csv(df, file.path(carpeta, nombre), na = "")
}
principal <- cfg$normalizacion$metodo_principal
inicio <- Sys.time()

# =============================================================================
# FASE 1 · Base, validación, inventario y margen
# =============================================================================
message("\n[Fase 1] Carga, validación, inventario y margen")
carga <- cargar_datos(cfg)
guardar(carga$registro, "registro_archivos.csv")

validaciones <- validar_datos(carga$partidos, carga$registro, cfg)
guardar(validaciones, "validaciones.csv")
imprimir_validacion(validaciones)

largo       <- cuotas_largo(carga$partidos, cfg) %>% marcar_muestra()
inventario  <- construir_inventario(largo)
exclusiones <- listar_exclusiones(largo)
muestra     <- resumen_muestra(largo)
guardar(inventario, "inventario_cobertura.csv")
write_csv(exclusiones, file.path(cfg$rutas$tablas, "exclusiones.csv"), na = "")
guardar(muestra, "resumen_muestra.csv")

base <- calcular_base_analitica(largo)
margen_global  <- resumir_margen(base, liga, casa, momento)
margen_temp    <- resumir_margen(base, liga, temporada, casa, momento)
margen_comp    <- comparaciones_margen(base, cfg)
ligas_por_temp <- comparar_ligas_por_temporada(base, cfg)
guardar(margen_global,  "margen_resumen_global.csv")
guardar(margen_temp,    "margen_por_temporada.csv")
guardar(margen_comp,    "margen_comparaciones.csv")
guardar(ligas_por_temp, "margen_ligas_por_temporada.csv")
graficar_margen(base, margen_temp, margen_comp, cfg)

# =============================================================================
# FASE 2 · Remoción del margen
# =============================================================================
message("\n[Fase 2] Remoción del margen: ", paste(cfg$normalizacion$metodos, collapse = ", "))
metodos <- unlist(cfg$normalizacion$metodos)
base <- aplicar_normalizacion(base, metodos)
print(verificar_normalizacion(base, metodos))
# Entregable 1: base analítica con cuotas, brutas, normalizadas, margen y resultado
guardar(base, "base_analitica.csv", carpeta = cfg$rutas$datos_procesados)

pred <- predicciones_largo(base)          # solo probabilidades normalizadas
guardar(resumen_parametros(base, metodos), "normalizacion_parametros.csv")
guardar(sensibilidad_metodos(pred, cfg),   "normalizacion_sensibilidad.csv")
graficar_sensibilidad_metodos(pred, cfg)

# =============================================================================
# FASE 3 · Evaluación de la calibración
# =============================================================================
message("\n[Fase 3] Curvas de calibración, puntuaciones, Murphy y Hosmer-Lemeshow")
curvas <- curvas_todas(pred, cfg)
curvas_desenlace <- curva_calibracion(pred, cfg$calibracion$esquema_principal,
                                      cfg$calibracion$n_intervalos,
                                      cfg$inferencia$nivel_confianza,
                                      grupos = c(grupos_base, "desenlace"))
resumen_curvas <- resumir_curvas(curvas)
ece_azar   <- ece_esperado_por_azar(pred, cfg)
metricas   <- metricas_partido(pred)
punt       <- puntuaciones(metricas, cfg)
desc_murphy <- murphy(pred, cfg)
hl         <- hosmer_lemeshow(pred, cfg)
grueso     <- grueso_por_desenlace(pred, cfg)

guardar(curvas, "calibracion_curvas.csv")
guardar(curvas_desenlace, "calibracion_curvas_por_desenlace.csv")
guardar(resumen_curvas, "calibracion_resumen.csv")
guardar(ece_azar, "calibracion_ece_vs_azar.csv")
guardar(punt, "puntuaciones.csv")
guardar(desc_murphy, "murphy.csv")
guardar(hl, "hosmer_lemeshow.csv")
guardar(grueso, "calibracion_grueso.csv")
graficar_calibracion(curvas, curvas_desenlace, cfg)

# =============================================================================
# FASE 4 · Desviaciones sistemáticas
# =============================================================================
message("\n[Fase 4] Sesgo favorito-longshot, casas, momentos y temporadas")
pendientes    <- pendiente_calibracion(pred, cfg)
rangos        <- desviacion_por_rango(pred, cfg)
comparaciones <- comparaciones_calibracion(pred, metricas, cfg)
temporal      <- por_temporada(metricas, cfg)
grueso_temp   <- grueso_por_desenlace(filter(pred, metodo == principal), cfg,
                                      grupos = c(grupos_base, "temporada"))

# Sensibilidad: lo confirmatorio, sin las temporadas indicadas en config.yml
excluir <- unlist(cfg$desviaciones$temporadas_sensibilidad_excluir)
pred_s  <- filter(pred, !anio_inicio %in% excluir, metodo == principal)
met_s   <- filter(metricas, !anio_inicio %in% excluir, metodo == principal)
etiqueta_s <- paste("sin", paste(etiqueta_temporada(excluir), collapse = ", "))
sens_comp <- comparaciones_calibracion(pred_s, met_s, cfg, metodos = principal) %>%
  mutate(analisis = etiqueta_s, .before = 1)
sens_pend <- pendiente_calibracion(pred_s, cfg) %>% mutate(analisis = etiqueta_s, .before = 1)

guardar(pendientes, "flb_pendiente.csv")
guardar(rangos, "flb_por_rango.csv")
guardar(comparaciones, "comparaciones_calibracion.csv")
guardar(temporal$niveles, "temporada_puntuaciones.csv")
guardar(temporal$diferencias, "temporada_diferencias_casas.csv")
guardar(grueso_temp, "temporada_grueso_por_desenlace.csv")
guardar(sens_comp, "sensibilidad_comparaciones.csv")
guardar(sens_pend, "sensibilidad_pendiente.csv")
graficar_desviaciones(rangos, comparaciones, pendientes, grueso_temp, temporal$niveles, cfg)

# =============================================================================
# FASE 5 · Reporte autogenerado
# =============================================================================
writeLines(capture.output(sessionInfo()), file.path(cfg$rutas$salidas, "sessionInfo.txt"))

if (isTRUE(cfg$reporte$generar)) {
  message("\n[Fase 5] Reporte de calibración")
  if (requireNamespace("rmarkdown", quietly = TRUE) && preparar_pandoc()) {
    rmarkdown::render(cfg$reporte$archivo, output_dir = cfg$rutas$salidas,
                      knit_root_dir = normalizePath("."), envir = new.env(),
                      quiet = TRUE)
    message("   Reporte en ", file.path(cfg$rutas$salidas, "reporte_calibracion.html"))
  } else {
    message("   No se generó el reporte: no se encontró pandoc. Ejecute ",
            "source(\"run_all.R\") desde RStudio, que ya lo incluye.")
  }
}

# --- Resumen en consola ------------------------------------------------------
message("\nMargen medio (pp):")
print(select(margen_global, liga, casa, momento, media, perdida_esperada_por_100), n = Inf)
message("\nCalibración (", principal, "): ECE observado frente al esperado por azar (pp)")
print(ece_azar %>% filter(metodo == principal) %>%
        select(liga, casa, momento, ece_observado_pp, ece_azar_media_pp, p_simulacion), n = Inf)
message("\nContrastes confirmatorios (", principal, "):")
print(comparaciones %>% filter(confirmatorio) %>%
        select(contraste, metrica, diferencia, ic_inf, ic_sup, p_holm_texto), n = Inf, width = Inf)

message(sprintf("\nListo en %.1f segundos. Tablas en %s, figuras en %s, base en %s.",
                as.numeric(difftime(Sys.time(), inicio, units = "secs")),
                cfg$rutas$tablas, cfg$rutas$figuras, cfg$rutas$datos_procesados))
